console.log('Hello World!');


const Clock = ()=>{
  const design = {
    fontFamily: "verdana",
    fontSize: "15px",
    fontWeight: "500",
    padding:  "4px",
    color:"blue"
  };
var d =  new Date();
var hour = d.getHours();
var minute = d.getMinutes();
var seconds = d.getSeconds();
 
/*Below inside the return method are the two of the ways in which  element can be styled in react 
namely:
1.Inline css(for single styling property)
2.css stylesheet(using object )
3.cssmodules */

return(<>
  <h1 style={{color: "red"}}>Hello Style!</h1>
    <h2 style={{color: "dodgerblue"}}>The time is {hour}:{minute}:{seconds}</h2>
  <p style={design}>Styling react can be kind of fun and impressive </p>
  </>  )
    setInterval(Clock,1000);
}
setInterval(Clock,1000);
/*function Clock(){
  return(<h2>{timing}</h2>)
}*/



const container = document.getElementById('root')
const root = ReactDOM.createRoot(container);
root.render(<Clock/>) 